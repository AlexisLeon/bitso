# Bitso Code Challenge

#### Pre requisites

 - NodeJs
 - Time (takes a while as is not my best code --> is not optimized)

## Run challenge

``
$ node solution.js
``
